
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from datetime import datetime
import requests
from os import getenv

STABILITY_KEY = getenv('STABILITY_KEY', 'your-key-here')
import os
import json

app = Flask(__name__, static_folder='static')
CORS(app)

NOTES_FILE = 'notes.json'

if os.path.exists(NOTES_FILE):
    with open(NOTES_FILE, 'r') as f:
        notes = json.load(f)
else:
    notes = []

@app.route('/')
def home():
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/note', methods=['POST'])
def store_note():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'Invalid JSON'}), 400

        note_text = data.get('note')
        category = data.get('category', 'Uncategorized')
        tags = data.get('tags', [])
        timestamp = data.get('timestamp', datetime.utcnow().isoformat())

        if not note_text:
            return jsonify({'error': 'Missing note text'}), 400

        note_entry = {
            'id': f'note_{len(notes)+1}',
            'note': note_text,
            'category': category,
            'tags': tags,
            'timestamp': timestamp
        }

        notes.append(note_entry)
        with open(NOTES_FILE, 'w') as f:
            json.dump(notes, f, indent=2)

        return jsonify({'status': 'saved', 'id': note_entry['id']})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/notes', methods=['GET'])
def get_notes():
    try:
        return jsonify(notes)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    @app.route('/api/generate-image', methods=['POST'])
    def generate_image():
        data = request.get_json()
        response = requests.post(
            "https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image",
            headers={"Authorization": f"Bearer {STABILITY_KEY}"},
            json=data
        )
        return response.json()

    @app.route('/api/generate-video', methods=['POST'])
    def generate_video():
        data = request.get_json()
        response = requests.post(
            "https://api.stability.ai/v2beta/image-to-video",
            headers={"Authorization": f"Bearer {STABILITY_KEY}"},
            json=data
        )
        return response.json()

    app.run(host='0.0.0.0', port=8080)
